#!/bin/sh

java -jar webswing-admin-server.war -admin -j jetty.properties

exit 0

